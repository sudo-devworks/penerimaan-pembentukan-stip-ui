import "./FormLabel.css";

export { FormLabel } from "./FormLabel";
export type { FormLabelProps } from "./FormLabel.types";
